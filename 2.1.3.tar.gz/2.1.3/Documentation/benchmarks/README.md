# Benchmarks

etcd benchmarks will be published regularly and tracked for each release below:

- [etcd v2.1.0](etcd-2-1-0-benchmarks.md)
